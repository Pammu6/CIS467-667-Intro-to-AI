import numpy as np

NETID = "gkatz01" # Replace with your NetID!
BLANK = "_"

def state_str(state, prefix=""):
    return "\n".join("%s%s" % (prefix, "".join(row)) for row in state)

def move(state, symbol, row, col):
    if state[row,col] != BLANK: return False
    new_state = state.copy()
    new_state[row,col] = symbol
    return new_state

def score(state):
    """
    Return the score for player X in the given state.
    Use the weights for your NetID as described in written.pdf.
    You can use the tictactoe.py file on blackboard as a starting point.
    """
    raise(NotImplementedError)

def dfs(state, symbol):
    """
    Replace the following with your implementation.
    Return the outputs described in written.pdf.
    You can use the tictactoe.py file on blackboard as a starting point.
    """
    leaf_count = 0
    expected_score = 0
    return leaf_count, expected_score

if __name__ == "__main__":

    state0 = np.array([[BLANK]*3]*3)
    
    state1 = move(state0, "x", 0, 0)
    state2 = move(state1, "x", 0, 0)
    print(state_str(state0))
    print(state_str(state1))
    print(state2)
    
    lc, v = dfs(state0, "x")
    print("DFS: leaf count = %d, expected value = %f" % (lc, v))
    
