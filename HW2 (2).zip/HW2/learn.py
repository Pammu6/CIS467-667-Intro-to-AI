"""
Provides a basic gradient descent algorithm for learning.
"""

def gradient_descent(parameters, error_function, num_iters, learning_rate, verbose=False):
    """
    Uses gradient descent to find parameters that minimize training error.
    Parameters should be a list of Variables and/or VariableArrays.
    error_function should be a function handle for computing error.
    error_function(parameters) should return a single Variable e.
    e is a variable dependent on the parameters representing their error.
    num_iters is the number of gradient descent iterations to perform.
    learning_rate is a fixed learning rate for the gradient descent.
    If verbose is true, prints the current error at each iteration.
    Returns a list errors, where error[i] is e at the start of the i^{th} iteration.
    """
    errors = []
    for each_iter in range(num_iters):
        errors.append(error_function(parameters))
        if verbose==True:
            print(errors[each_iter])
        # parameters = np.subtract(parameters,learning_rate*parameters.gradient(errors[each_iter]))
        for i in range(len(parameters)):
            # print(each_iter,errors[each_iter],"param",parameters[i] ,parameters[i].gradient(errors[each_iter]))
            parameters[i] = parameters[i] - learning_rate*parameters[i].gradient(errors[each_iter])
            # print(each_iter,errors[each_iter],"param",parameters[i] ,parameters[i].gradient(errors[each_iter]))
    return errors
    # raise(NotImplementedError)
  
if __name__ == "__main__":

    """
    Scratch pad for informal testing.
    You can edit the following without affecting the tests.
    Shows an example using gradient descent to train a linear regression model.
    An example with a neural network model is given in tests.py.
    """

    import numpy as np
    from variable_array import VariableArray
    
    # Random training data
    X = np.random.randn(2,4)
    Y = np.random.randn(2,4)
    print("X, Y")
    print(X)
    print(Y)
    X = np.array([[-0.55427249,  0.40034063, -1.40994713,  0.51925678],
                      [ 0.34043718,  0.02484774,  1.02835799,  0.50503202]])
    Y = np.array([[ 1.13055928, -0.90340322,  1.90165584, -1.09158475],
                      [ 0.29670035, -0.25619711,  0.46959747, -0.33156514]])
    # Initialize the regression parameters to zero
    # Trying to learn Y ~ W.dot(X)
    W = VariableArray(np.zeros((2,2)))
    
    parameters = [W]
    W = [VariableArray(np.array([[-0.50043522, -0.15420026],
                                     [ 0.34272670,  0.24172611]])),
             VariableArray(np.array([[ 1.17618063,  1.2767736 ],
                                     [ 0.96057281, -0.66617526]]))]
    parameters = [W]
    # print("initial W")
    # print(W)
    # def error_function(params):
    #     e = np.sum((params[0].dot(X) - Y)**2) # sum of squared errors
    #     return e
    def error_function(parameters):
            return np.sum((parameters[1].dot(np.tanh(parameters[0].dot(X))) - Y)**2) 
    # print("error",error_function(W))
    # Use gradient descent to find best parameters
    gradient_descent(W, error_function, num_iters=10, learning_rate=0.01, verbose=True)

    # W after learning
    print("learned W")
    print(W)
